.text
.global matrix_chain_multiplication

matrix_chain_multiplication:
    # Prologue - minimized register saves
    addi sp, sp, -48
    sw ra, 44(sp)
    sw s0, 40(sp)
    sw s1, 36(sp)
    sw s2, 32(sp)
    sw s3, 28(sp)
    sw s4, 24(sp)
    sw s5, 20(sp)
    sw s6, 16(sp)
    sw s7, 12(sp)
    sw s8, 8(sp)
    sw s9, 4(sp)
    sw s10, 0(sp)
    
    # Save input parameters
    mv s0, a0        # matrices
    mv s1, a1        # rows
    mv s2, a2        # cols
    mv s3, a3        # count
    
    # OPTIMIZATION 1: Single allocation for M and S tables
    mul t0, s3, s3   # count * count
    slli t1, t0, 3   # * 8 (for both M and S tables)
    mv a0, t1
    call malloc
    mv s4, a0        # s4 = M table
    
    # S table starts after M table
    slli t0, t0, 2   # count * count * 4
    add s5, s4, t0   # s5 = S table
    
    # PHASE 1: DP computation - Initialize M[i][i] = 0
    li t0, 0         # i = 0
init_diagonal:
    mul t1, t0, s3   # i * count
    add t1, t1, t0   # i * count + i
    slli t1, t1, 2   # * 4
    add t1, s4, t1   # &M[i][i]
    sw zero, 0(t1)   # M[i][i] = 0
    
    addi t0, t0, 1   # i++
    blt t0, s3, init_diagonal
    
    # Main DP loop
    li s6, 2         # l = 2 (chain length)
    slli a7,s3,2
    
for_l:
    li s7, 0         # i = 0

    # Calculate j = i + l - 1
    addi s8, s6,-1   # j0 = i + l - 1 = l - 1    # end i_loop with i++ and j++
    
    # for_i boundary
    sub  a4, s3, s6   # count - l
    addi a4, a4, 1   # count - l + 1
    
for_i:
    # Initialize M[i][j] to infinity
    li t0, 0x7FFFFFFF
    mul t1, s7, s3   # i * count
    add t5, t1, s8   # i * count + j
    slli t5, t5, 2   # * 4
    add t6, s5, t5   # &S[i][j] stored in t6
    add t5, s4, t5   # &M[i][j] stored in t5
    sw t0, 0(t5)     # M[i][j] = infinity
    
    # Try all split points k = i to j-1
    addi s11, s7,-1       # k-1 = i-1
    
    # &M[i][k] stored in a5
    add  t0, t1, s11 # i * count +k
    slli t0, t0, 2   # * 4
    add  a5, s4, t0  # &M[i][k]
    
    # OPTIMIZATION 2: Cache dimension values   (s10= cols[j]*rows[i])
    slli t1, s7, 2   # i * 4
    add t1, s1, t1   # &rows[i]
    lw s9, 0(t1)     # rows[i] (cache for k loop)
    
    slli t1, s8, 2   # j * 4
    add t1, s2, t1   # &cols[j]
    lw s10, 0(t1)    # s10 = cols[j] (cache for k loop)
    
    mul s10,s10,s9   # cols[j]*rows[i]
    
    
    # s9 = &cols[k]
    slli s9, s11, 2  # k * 4
    add s9, s2, s9   # &cols[k]
    

    # &M[k+1][j] stored in a6
    mv s11, s7       # k = i
    
    mul t0, s11, s3   # (k+1) * count
    add t0, t0, s8   # (k+1) * count + j
    slli t0, t0, 2   # * 4
    add a6, s4, t0   # &M[k+1][j]

for_k:
    # Calculate cost: M[i][k] + M[k+1][j] + rows[i] * cols[k] * cols[j]

    # Get M[i][k]
    addi a5,a5,4
    lw t1, 0(a5)     # t1 = M[i][k]
    
    # Get M[k+1][j]
    add  a6,a6,a7
    lw t2, 0(a6)     # t2 = M[k+1][j]
    
    # Get cols[k]
    addi s9,s9,4
    lw t3, 0(s9)     # t3 = cols[k]
    
    # Compare with current M[i][j]
    lw t0, 0(t5)     # current M[i][j]
    
    # Calculate cost: M[i][k] + M[k+1][j] + rows[i] * cols[k] * cols[j]
    mul t4, s10, t3  # rows[i] * cols[k] * cols[j] (using cached cols[j])
    add t4, t4, t1   # + M[i][k]
    add t4, t4, t2   # + M[k+1][j]
    
    # If new cost is better, update
    bge t4, t0, skip_update
    
    # Update M[i][j]
    sw t4, 0(t5)
    
    # Update S[i][j]
    sw s11, 0(t6)    # S[i][j] = k
    
skip_update:
    addi s11, s11, 1 # k++
    blt s11, s8, for_k
    
    # Continue i loop
    addi s7, s7, 1   # i++
    addi s8, s8, 1   # j++
    blt s7, a4, for_i
    
    # Continue length loop
    addi s6, s6, 1   # l++
    ble s6, s3, for_l
    
    # PHASE 2: Allocate result table
    mul t0, s3, s3   # count * count
    slli t0, t0, 2   # * 4
    mv a0, t0
    call malloc
    mv s6, a0        # s6 = result table
    
    # Initialize result table with single matrices
    li t0, 0         # i = 0
init_result_table:
    # result[i][i] = matrices[i]
    slli t1, t0, 2   # i * 4
    add t1, s0, t1   # &matrices[i]
    lw t2, 0(t1)     # matrices[i]
    
    mul t1, t0, s3   # i * count
    add t1, t1, t0   # i * count + i
    slli t1, t1, 2   # * 4
    add t1, s6, t1   # &result[i][i]
    sw t2, 0(t1)     # result[i][i] = matrices[i]
    
    addi t0, t0, 1   # i++
    blt t0, s3, init_result_table
    
    # PHASE 3: Bottom-up multiplication using S table
    li s7, 2         # l = 2
    
multiply_length_loop:
    li s8, 0         # i = 0
    
multiply_i_loop:
    # Calculate j = i + l - 1
    add s9, s8, s7   # i + l
    addi s9, s9, -1  # j = i + l - 1
    
    # Get optimal split point k = S[i][j]
    mul t0, s8, s3   # i * count
    add t0, t0, s9   # i * count + j
    slli t0, t0, 2   # * 4
    add t0, s5, t0   # &S[i][j]
    lw s10, 0(t0)    # k = S[i][j]
    
    # Get left matrix: result[i][k]
    mul t0, s8, s3   # i * count
    add t0, t0, s10  # i * count + k
    slli t0, t0, 2   # * 4
    add t0, s6, t0   # &result[i][k]
    lw s11, 0(t0)    # left_matrix = result[i][k]
    
    # Get right matrix: result[k+1][j]
    addi t1, s10, 1  # k + 1
    mul t0, t1, s3   # (k+1) * count
    add t0, t0, s9   # (k+1) * count + j
    slli t0, t0, 2   # * 4
    add t0, s6, t0   # &result[k+1][j]
    lw t0, 0(t0)     # right_matrix = result[k+1][j]
    
    # Get dimensions for multiplication
    slli t1, s8, 2   # i * 4
    add t1, s1, t1   # &rows[i]
    lw t1, 0(t1)     # rows_left = rows[i]
    
    slli t2, s10, 2  # k * 4
    add t2, s2, t2   # &cols[k]
    lw t2, 0(t2)     # cols_left = cols[k]
    
    slli t3, s9, 2   # j * 4
    add t3, s2, t3   # &cols[j]
    lw t3, 0(t3)     # cols_right = cols[j]
    
    # Call matrix multiplication
    mv a0, t1        # rows_left
    mv a1, t2        # cols_left
    mv a2, t3        # cols_right
    mv a3, s11       # left_matrix
    mv a4, t0        # right_matrix
    
    # Save only essential registers - reduce stack overhead
    addi sp, sp, -20
    sw s7, 16(sp)
    sw s8, 12(sp)
    sw s9, 8(sp)
    sw s10, 4(sp)
    sw s11, 0(sp)
    
    call multiply_two_matrices
    
    # Restore registers
    lw s11, 0(sp)
    lw s10, 4(sp)
    lw s9, 8(sp)
    lw s8, 12(sp)
    lw s7, 16(sp)
    addi sp, sp, 20
    
    # Store result in result[i][j] - optimize addressing
    mul t0, s8, s3   # i * count
    add t0, t0, s9   # i * count + j
    slli t0, t0, 2   # * 4
    add t0, s6, t0   # &result[i][j]
    sw a0, 0(t0)     # result[i][j] = multiplication result
    
    # Continue i loop
    addi s8, s8, 1   # i++
    sub t0, s3, s7   # count - l
    addi t0, t0, 1   # count - l + 1
    blt s8, t0, multiply_i_loop
    
    # Continue length loop
    addi s7, s7, 1   # l++
    ble s7, s3, multiply_length_loop
    
    # Get final result: result[0][count-1]
    addi t0, s3, -1  # count - 1
    slli t0, t0, 2   # * 4
    add t0, s6, t0   # &result[0][count-1]
    lw t1, 0(t0)     # final result matrix
    
    # Free allocated memory
    mv a0, s4        # free M+S table
    call free
    mv a0, s6        # free result table
    call free
    
    # Return final result
    mv a0, t1
    j epilogue


epilogue:
    # Restore registers and return
    lw s10, 0(sp)
    lw s9, 4(sp)
    lw s8, 8(sp)
    lw s7, 12(sp)
    lw s6, 16(sp)
    lw s5, 20(sp)
    lw s4, 24(sp)
    lw s3, 28(sp)
    lw s2, 32(sp)
    lw s1, 36(sp)
    lw s0, 40(sp)
    lw ra, 44(sp)
    addi sp, sp, 48
    jr ra

# OPTIMIZATION 3: Optimized matrix multiplication with reduced instruction overhead
multiply_two_matrices:
    # Prologue - minimize register saves
    addi sp, sp, -24
    sw ra, 20(sp)
    sw s0, 16(sp)
    sw s1, 12(sp)
    sw s2, 8(sp)
    sw s3, 4(sp)
    sw s4, 0(sp)
    
    mv s0, a0        # rows_left
    mv s1, a1        # cols_left
    mv s2, a2        # cols_right
    mv s3, a3        # left_matrix
    mv s4, a4        # right_matrix
    
    # Allocate result matrix
    mul t0, s0, s2   # rows_left * cols_right
    slli t0, t0, 2   # * 4 bytes
    mv a0, t0
    call malloc
    mv a7, a0        # a7 = result_matrix
    
    # Pre-calculate constants to eliminate inner loop calculations
    slli t5, s2, 2   # cols_right * 4 (B row stride)
    slli t3, s1, 2   # cols_left * 4 (A row stride)
    
    # Triple nested loop for matrix multiplication
    li t0, 0         # i = 0
    mv t6, s3        # current A row pointer
    
mult_i_loop:
    li t1, 0         # j = 0
    mul a0, t0, s2   # i * cols_right
    slli a0, a0, 2   # * 4
    add t4, a7, a0   # &result[i][0]
    
mult_j_loop:
    mv t2, s1        # k = cols_left
    li a1, 0         # sum = 0
    mv a2, t6        # A row pointer
    slli a0, t1, 2   # j * 4
    add a3, s4, a0   # &B[0][j]
    
mult_k_loop:
    lw a4, 0(a2)     # A[i][k]
    lw a5, 0(a3)     # B[k][j]
    addi a2, a2, 4   # advance A pointer
    add a3, a3, t5   # advance B pointer
    mul a6, a4, a5   # A[i][k] * B[k][j]
    add a1, a1, a6   # sum += product
    addi t2, t2, -1  # k--
    bnez t2, mult_k_loop
    
    # Store C[i][j] = sum and advance pointer in one step
    sw a1, 0(t4)     # result[i][j] = sum
    addi t4, t4, 4   # advance result pointer
    
    # Continue j loop
    addi t1, t1, 1   # j++
    blt t1, s2, mult_j_loop
    
    # Advance to next A row using pre-calculated stride
    add t6, t6, t3   # advance A row pointer
    
    # Continue i loop
    addi t0, t0, 1   # i++
    blt t0, s0, mult_i_loop
    
    # Return result matrix
    mv a0, a7
    
    # Epilogue
    lw s4, 0(sp)
    lw s3, 4(sp)
    lw s2, 8(sp)
    lw s1, 12(sp)
    lw s0, 16(sp)
    lw ra, 20(sp)
    addi sp, sp, 24
    jr ra
